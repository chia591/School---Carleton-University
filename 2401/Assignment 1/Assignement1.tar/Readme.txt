Andy Chia - 101111058

Source files submitted: cards.c, patioBuilder.c

To test patioBuilder:
    gcc patioBuilder.c -lm
    ./a.out

    -Follow instructions given to the user in the program 
        Input dimensions in feet

To test cards
    gcc cards
    ./a.out 

    -Follow instructions given to the user in the program
        Input the trump suit 
        Input the remaining cards for each players
        enter '.' at any time to leave the program