Andy Chia - 101111058

files: createBinary.c, multiFactor.c, numPrimeFactors (executable), numPrimeFactors.c, prime_threads.c, prime.bin, prime.txt

3. Task I
to test multiFactor:
    make sure that the executable for numPrimeFactors is in the folder, if its not then run:
        gcc -o numPrimeFactors numPrimeFactors.c

    compile multiFactor:
        gcc multiFactor.c
    
    run multiFactor
        Without any files:
            ./a.out
        with file:
            ./a.out prime.bin

thats as far as i got as i had problems creating children for the code.

4. Task II
    not done, some of the logic is there but couldent figure out how to get it to work.