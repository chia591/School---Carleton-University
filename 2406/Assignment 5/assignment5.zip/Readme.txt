Andy Chia - 101111058

required libraries:
npm install express
npm install mongoose
npm install pug

test urls:
http://localhost:3000/
http://localhost:3000/quiz
http://localhost:3000/users