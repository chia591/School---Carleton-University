let string;
string = "#"
for (let y = 1; y < 8; y++){
   console.log(string);
   string += "#";
}