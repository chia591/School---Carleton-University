Assignment 4 - COMP2404B - Andy Chia - 101111058

Files: Control.cc, Control.h, Date.cc, Date.h, List.h, main.cc, Makefile, Object.cc, Object.h, Student.cc, Student.h, View.cc, View.h

To Compile and Run:
  make run

  3 to view students
    From there:
      1 - Test out students with same name and different names
      2 - Test out removing students or dates with the id that can be seen in () from the list of students 
