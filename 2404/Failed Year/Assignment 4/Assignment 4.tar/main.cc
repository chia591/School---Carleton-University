#include "Control.h"

int main()
{
    //cout<<"1"<<endl;
    Control c;
    c.launch();
    return 0;
}
