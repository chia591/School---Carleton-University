#ifndef RANDOM_H
#define RANDOM_H

#include <iostream>
#include <cstdlib>

int random(int);

#endif