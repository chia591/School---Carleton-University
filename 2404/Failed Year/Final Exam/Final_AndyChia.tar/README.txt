Andy Chia - 101111058

Files: Controler.cc, Controler.h, Figher.cc, Fighter.h, main.cc, Makefile, Map.cc, Map.h, Prince.cc, Prince.h, random.cc, random.h, FinalExamUML.pdf

Purpose: To recreate the adventure of Timmy and Harold in their journey to retreive the emeral in a game

To run the Program:
    make
    make run

spaming a letter will progress,

entering e will exit the Program

all is completed but colisions and completion function. 